from unicodedata import category

from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.views import APIView

from products.models import Category, Product


# Create your views here.

@api_view(['POST'])
def createCategories(request):
    payload = request.data
    cat = Category()
    cat.name = payload["name"]
    cat.is_active = True
    cat.save()
    return Response(data={})

@api_view(['GET'])
def getCategories(request):
    cat = Category.objects.filter(is_active=True).values()
    return Response(data=cat)

@api_view(['PUT'])
def updateCategories(request):
    payload = request.data
    item_id = payload["id"]
    cat = Category.objects.filter(id=item_id).first()
    if cat:
        cat.name = payload["name"]
        cat.save()
        return Response(data={
            "success": True,
            "description": "Category Updated successfully"
        })
    else:
        return Response(data={
            "success": False,
            "description":"no such item exists"
        })


class Products(APIView):

    def post(self, request):
        payload = request.data
        product = Product()
        product.name = payload["name"]
        product.category_name = payload["category_name"]
        product.qty = payload["qty"]
        product.price = payload["price"]
        product.discount = payload["discount"]
        product.rating = payload["rating"]
        product.description = payload["description"]
        product.save()
        return Response(data={
            "success":True
        })

    def get(self, request):
        params = request.GET
        products = Product.objects.filter(is_active=True, category_name=params["cat"]).values()
        return Response(data=products)



