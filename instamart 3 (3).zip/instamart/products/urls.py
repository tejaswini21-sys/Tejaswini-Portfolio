from django.urls import path

from products.views import createCategories, getCategories, updateCategories, Products

urlpatterns = [
    path('createCategory', createCategories),
    path('getCategories', getCategories),
    path('updateCategory', updateCategories),

    path('products', Products.as_view()),

]