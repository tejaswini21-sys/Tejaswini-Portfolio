from django.db import models

# Create your models here.

class Category(models.Model):
    name = models.CharField(unique=True, null=False, max_length=30)
    is_active = models.BooleanField(default=True)



class Product(models.Model):
    name = models.CharField(max_length=30)
    category_name = models.CharField(max_length=30)
    price = models.FloatField(default=0.0)
    qty = models.FloatField(default=0.0)
    discount = models.FloatField(default=0.0)
    rating = models.FloatField(default=0.0)
    description = models.CharField(max_length=500)
    is_active = models.BooleanField(default=True)



