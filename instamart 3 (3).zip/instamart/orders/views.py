from datetime import datetime
from itertools import product

from django.shortcuts import render
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from orders.models import Orders
from products.models import Product


# Create your views here.


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def orderItems(request):
    payload = request.data
    order = Orders()

    product = Product.objects.filter(id=payload["product_id"]).first()
    if not product:
        return Response(data={
            "success":False,
            "description":"given id for product is not available in our database"
        })

    order.user_id = payload["user_id"]
    order.product_id = payload["product_id"]
    order.address_id = payload["address_id"]
    order.price = payload["price"]
    order.gst = payload["gst"]
    order.tax = payload["tax"]
    order.payment_mode = payload["payment_mode"]
    order.status = "PENDING"
    order.date = datetime.now()
    order.save()
    return Response(data={
        "success":True
    })