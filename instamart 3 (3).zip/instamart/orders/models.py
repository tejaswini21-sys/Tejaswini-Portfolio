from django.db import models

# Create your models here.

class Orders(models.Model):
    user_id = models.BigIntegerField()
    product_id = models.BigIntegerField()
    address_id = models.BigIntegerField()
    price = models.FloatField()
    gst = models.FloatField()
    tax = models.FloatField()
    date = models.DateTimeField()
    status=models.CharField(default='ORDERED', max_length=20)
    payment_mode = models.CharField(default='COD')
