from django.urls import path

from orders.views import orderItems

urlpatterns = [
    path('order', orderItems)
]