from django.urls import path

from userservice.views import signUp, signIn, addAddress

urlpatterns = [
    path('signup', signUp),
    path('signIn', signIn),
    path('addAddress', addAddress),
]