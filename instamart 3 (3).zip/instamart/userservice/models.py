from django.contrib.auth.base_user import AbstractBaseUser
from django.db import models

# Create your models here.
class UserMaster(AbstractBaseUser):
    username = models.CharField(default='', max_length=40, null=False)
    mobile = models.CharField( max_length=10, null=False, unique=True)
    email = models.CharField( max_length=50, null=False, unique=True)
    password = models.CharField( max_length=10, null=False)
    dob = models.CharField(max_length=12, null=True)
    city = models.CharField(max_length=30, null=True)
    creation_date = models.DateTimeField(auto_now_add=True, null=True)
    USERNAME_FIELD = "mobile"

    REQUIRED_FIELDS = []


class address(models.Model):
    user_id = models.BigIntegerField(default=1)
    name = models.CharField(max_length=20)
    address1 = models.CharField(max_length=100, null=True)
    address2 = models.CharField(max_length=100, null=True)
    street = models.CharField(max_length=100)
    landmark = models.CharField(max_length=20)
    pincode = models.CharField(max_length=6)
    district = models.CharField(max_length=30)
    phone_number = models.CharField(max_length=10)
    is_default = models.BooleanField(default=False)




