
from django.shortcuts import render
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken

from userservice.models import UserMaster, address


# Create your views here.

@api_view(['POST'])
def signUp(request):
    payload = request.data
    user = UserMaster()
    user.email = payload["email"]
    user.mobile = payload["mobile"]
    user.password = payload["password"]
    user.dob = payload["dob"]
    user.username = payload["username"]
    user.city = payload["city"]
    user.save()
    return Response(data={
        "success": True,
        "description": "Signup Completed Successfully!",
        "info": {}
    })

@api_view(['POST'])
def signIn(request):
    payload = request.data
    mobile = payload["mobile"]
    password = payload["password"]

    user = UserMaster.objects.filter(mobile=mobile, password=password).first()
    if user:

        token = RefreshToken.for_user(user)
        resp={
            "token": str(token.access_token)
        }



        return Response(data={
            "success": True,
            "description":"Login Successfull",
            "info": resp
        })
    else:
        return Response(data={
            "success": False,
            "description": "Login Failed",
            "info": {}
        })


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def addAddress(request):
    print(request.headers)
    print(request.user)
    user = request.user
    payload = request.data
    add = address()

    add.user_id = user.id
    add.name = user.username
    add.phone_number = payload["phone_number"]
    add.address1 = payload["address1"]
    add.address2 = payload["address2"]
    add.street = payload["street"]
    add.landmark = payload["landmark"]
    add.pincode = payload["pincode"]
    add.district = payload["district"]
    add.is_default = payload["is_default"]
    add.save()
    return Response(data={
        "success":True
    })